numbers.map({ number in 3 * number })
