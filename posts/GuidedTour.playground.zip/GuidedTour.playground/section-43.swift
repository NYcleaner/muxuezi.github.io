numbers.map({
    (number: Int) -> Int in
    let result = 3 * number
    return result
})
